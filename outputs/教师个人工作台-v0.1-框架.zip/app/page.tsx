import type { Metadata } from "next";
import TeacherWorkbench from "./TeacherWorkbench";

export const metadata: Metadata = {
  title: "教师个人工作台 · 框架演示",
  description: "面向老师个人的本地工作台框架：学生档案、教学课表、任务提醒与手机只读快照。",
};

export default function Home() {
  return <TeacherWorkbench />;
}
