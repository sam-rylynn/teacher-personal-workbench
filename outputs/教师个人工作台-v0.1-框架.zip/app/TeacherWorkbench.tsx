"use client";

import { useEffect, useMemo, useState } from "react";

type ViewKey = "today" | "teaching" | "students" | "tasks" | "resources";
type TaskKind = "全部" | "教学" | "学生" | "行政" | "论文";

type Student = {
  id: string;
  name: string;
  className: string;
  initials: string;
  color: string;
  latest: string;
  attendance: string;
  followUp: string;
  score: number;
  trend: string;
  timeline: Array<{ date: string; type: string; fact: string; next?: string }>;
};

type WorkTask = {
  id: string;
  kind: Exclude<TaskKind, "全部">;
  title: string;
  due: string;
  duration: string;
  link: string;
  progress?: string;
  urgent?: boolean;
};

const navItems: Array<{ key: ViewKey; label: string; icon: string }> = [
  { key: "today", label: "今日", icon: "⌂" },
  { key: "teaching", label: "教学", icon: "▦" },
  { key: "students", label: "学生", icon: "◎" },
  { key: "tasks", label: "事项", icon: "✓" },
  { key: "resources", label: "资料", icon: "◇" },
];

const students: Student[] = [
  {
    id: "S08403",
    name: "李明澈",
    className: "八年级4班",
    initials: "明澈",
    color: "sage",
    latest: "标出两处动作描写，并注明对应段落位置",
    attendance: "本学期 9 次课记录完整",
    followUp: "下一课比较动作描写与情感表达",
    score: 88,
    trend: "+4",
    timeline: [
      {
        date: "今天 08:34",
        type: "课堂观察",
        fact: "在课本中标出两处动作描写；汇报时说出对应段落位置；同伴补充后增加一处标记。",
        next: "下节课请其比较三处描写分别传递了什么信息。",
      },
      {
        date: "9月12日",
        type: "阅读问题单",
        fact: "文本证据题 4 项完成，教师复核 3 项准确、1 项需补充段落依据。",
      },
    ],
  },
  {
    id: "S08412",
    name: "赵清禾",
    className: "八年级4班",
    initials: "清禾",
    color: "apricot",
    latest: "请假后的补学清单 3 项已完成 2 项",
    attendance: "9月13日请假，记录已确认",
    followUp: "查看剩余阅读题，截止 9月17日",
    score: 84,
    trend: "+2",
    timeline: [
      {
        date: "今天 15:58",
        type: "班务参与",
        fact: "将小组提出的 5 项运动会建议按报名、物资、秩序分为三类。",
        next: "将整理结果关联到运动会报名汇总任务。",
      },
      {
        date: "9月13日",
        type: "出勤",
        fact: "请假记录已确认，系统生成 3 项补学清单，目前完成 2 项。",
      },
    ],
  },
  {
    id: "S08207",
    name: "陈屿安",
    className: "八年级2班",
    initials: "屿安",
    color: "blue",
    latest: "依据同伴追问重新查看文本并补充两处依据",
    attendance: "本学期 8 次课记录完整",
    followUp: "下次课查看修改前后两版答案",
    score: 91,
    trend: "+6",
    timeline: [
      {
        date: "今天 09:33",
        type: "课堂回答",
        fact: "第一次回答后重新查看文本，约 40 秒后补充两处文本依据，并写下修改后的答案。",
        next: "保留前后两版答案，下次复盘为什么修改。",
      },
      {
        date: "9月14日",
        type: "预习单",
        fact: "完成 5 项文本标记，均保留原文位置。",
      },
    ],
  },
  {
    id: "S08219",
    name: "周雨桐",
    className: "八年级2班",
    initials: "雨桐",
    color: "rose",
    latest: "提交 620 字叙事写作初稿",
    attendance: "本学期 8 次课记录完整",
    followUp: "9月17日前完成第二稿",
    score: 86,
    trend: "+3",
    timeline: [
      {
        date: "9月12日",
        type: "写作初稿",
        fact: "提交 620 字初稿，开头与结尾呼应，第二段时间顺序待调整。",
        next: "9月17日前提交第二稿。",
      },
    ],
  },
  {
    id: "S08231",
    name: "方知夏",
    className: "八年级2班",
    initials: "知夏",
    color: "violet",
    latest: "订正 4 个字词，复核栏均已填写",
    attendance: "本学期 8 次课记录完整",
    followUp: "下节课核对第三题补写",
    score: 89,
    trend: "+1",
    timeline: [
      {
        date: "9月14日",
        type: "订正记录",
        fact: "订正 4 个字词并填写复核栏，第三题补写尚未核对。",
        next: "下节课核对第三题。",
      },
    ],
  },
  {
    id: "S08427",
    name: "孙予宁",
    className: "八年级4班",
    initials: "予宁",
    color: "teal",
    latest: "提交 2分18秒重点段落朗读录音",
    attendance: "本学期 9 次课记录完整",
    followUp: "暂无待跟进",
    score: 92,
    trend: "+2",
    timeline: [
      {
        date: "9月14日",
        type: "朗读练习",
        fact: "提交重点段落朗读录音，时长 2 分 18 秒。",
      },
    ],
  },
  {
    id: "S08605",
    name: "王星野",
    className: "八年级6班",
    initials: "星野",
    color: "gold",
    latest: "论证卡写有 1 个观点和 2 条理由",
    attendance: "本学期 7 次课记录完整",
    followUp: "补充事实材料来源",
    score: 82,
    trend: "+5",
    timeline: [
      {
        date: "9月14日",
        type: "论证卡",
        fact: "写有 1 个观点和 2 条理由，其中一条事实材料尚未标注来源。",
        next: "下次写作课补充材料来源。",
      },
    ],
  },
  {
    id: "S08616",
    name: "郑书言",
    className: "八年级6班",
    initials: "书言",
    color: "coral",
    latest: "主动标出一项与观点关系不直接的论据",
    attendance: "本学期 7 次课记录完整",
    followUp: "9月16日提交替换论据",
    score: 87,
    trend: "+4",
    timeline: [
      {
        date: "今天 10:36",
        type: "写作过程",
        fact: "核对提纲时发现一个事例与观点关系不直接，并在该项旁标注待更换。",
        next: "只检查新论据与观点的对应关系。",
      },
    ],
  },
];

const initialTasks: WorkTask[] = [
  {
    id: "T002",
    kind: "教学",
    title: "批改八2阅读问题单并记录共性问题",
    due: "明天 17:00",
    duration: "约 50 分钟",
    link: "八年级2班",
    progress: "18 / 44",
    urgent: true,
  },
  {
    id: "T003",
    kind: "行政",
    title: "汇总八4运动会报名及志愿岗位",
    due: "明天 16:00",
    duration: "约 20 分钟",
    link: "八年级4班",
    urgent: true,
  },
  {
    id: "T004",
    kind: "学生",
    title: "核对赵清禾补学清单剩余阅读题",
    due: "9月17日 12:00",
    duration: "约 10 分钟",
    link: "赵清禾",
  },
  {
    id: "T005",
    kind: "学生",
    title: "查看郑书言替换后的论据是否支持观点",
    due: "明天 18:00",
    duration: "约 10 分钟",
    link: "郑书言",
  },
  {
    id: "T006",
    kind: "论文",
    title: "阅读2篇课堂提问等待时间研究并完成文献卡",
    due: "9月20日 20:00",
    duration: "约 70 分钟",
    link: "课堂提问研究",
  },
];

const scheduleRows = [
  { time: "07:40", mon: "八4 · 早读", tue: "八4 · 早读", wed: "八4 · 早读", thu: "八4 · 早读", fri: "八4 · 早读" },
  { time: "08:10", mon: "八2 · 语文", tue: "八4 · 语文", wed: "八6 · 写作", thu: "八2 · 语文", fri: "八4 · 语文" },
  { time: "09:05", mon: "八4 · 语文", tue: "八2 · 语文", wed: "八4 · 语文", thu: "八6 · 写作", fri: "八2 · 语文" },
  { time: "10:10", mon: "备课", tue: "八6 · 写作", wed: "八2 · 语文", thu: "教研活动", fri: "八6 · 写作" },
  { time: "15:50", mon: "年级会", tue: "八4 · 班会", wed: "作业辅导", thu: "八4 · 班会", fri: "自由备课" },
];

const resources = [
  { type: "教案", name: "《背影》第一课时教学设计", meta: "关联 3 个班级 · 今天更新", tone: "sage" },
  { type: "课件", name: "动作描写与人物情感.pptx", meta: "18 页 · 12.4 MB", tone: "apricot" },
  { type: "表格", name: "八2阅读问题单批改记录.xlsx", meta: "18 / 44 已完成", tone: "blue" },
  { type: "论文", name: "课堂提问等待时间 · 阅读卡", meta: "2 篇待阅读", tone: "violet" },
  { type: "模板", name: "课后收口四问", meta: "已用于 21 个课次", tone: "rose" },
  { type: "归档", name: "2025—2026学年教学资料", meta: "只读 · 386 个文件", tone: "teal" },
];

function Pill({ children, tone = "neutral" }: { children: React.ReactNode; tone?: string }) {
  return <span className={`pill pill-${tone}`}>{children}</span>;
}

function Avatar({ student, size = "normal" }: { student: Student; size?: "small" | "normal" | "large" }) {
  return <span className={`avatar avatar-${student.color} avatar-${size}`}>{student.initials}</span>;
}

function SectionHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  actions?: React.ReactNode;
}) {
  return (
    <div className="section-header">
      <div>
        {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
        <h1>{title}</h1>
        {description ? <p className="section-description">{description}</p> : null}
      </div>
      {actions ? <div className="section-actions">{actions}</div> : null}
    </div>
  );
}

export default function TeacherWorkbench() {
  const [activeView, setActiveView] = useState<ViewKey>("today");
  const [selectedStudentId, setSelectedStudentId] = useState(students[0].id);
  const [studentQuery, setStudentQuery] = useState("");
  const [studentClass, setStudentClass] = useState("全部班级");
  const [taskFilter, setTaskFilter] = useState<TaskKind>("全部");
  const [completedTasks, setCompletedTasks] = useState<string[]>([]);
  const [globalQuery, setGlobalQuery] = useState("");
  const [searchOpen, setSearchOpen] = useState(false);
  const [quickAddOpen, setQuickAddOpen] = useState(false);
  const [lessonOpen, setLessonOpen] = useState(false);
  const [importOpen, setImportOpen] = useState(false);
  const [importStep, setImportStep] = useState(1);
  const [publishOpen, setPublishOpen] = useState(false);
  const [publishStep, setPublishStep] = useState(1);
  const [mobilePreviewOpen, setMobilePreviewOpen] = useState(false);
  const [agentDraftOpen, setAgentDraftOpen] = useState(false);
  const [lastPublished, setLastPublished] = useState("9月15日 16:45");
  const [toast, setToast] = useState("");
  const [readOnly, setReadOnly] = useState(false);

  const selectedStudent = students.find((student) => student.id === selectedStudentId) ?? students[0];

  const filteredStudents = useMemo(() => {
    const query = studentQuery.trim();
    return students.filter((student) => {
      const matchesQuery = !query || `${student.name}${student.className}${student.latest}`.includes(query);
      const matchesClass = studentClass === "全部班级" || student.className === studentClass;
      return matchesQuery && matchesClass;
    });
  }, [studentClass, studentQuery]);

  const filteredTasks = useMemo(
    () => initialTasks.filter((task) => taskFilter === "全部" || task.kind === taskFilter),
    [taskFilter],
  );

  const searchResults = useMemo(() => {
    const query = globalQuery.trim();
    if (!query) return [];
    const studentResults = students
      .filter((student) => `${student.name}${student.className}${student.latest}`.includes(query))
      .map((student) => ({ type: "学生", title: student.name, meta: `${student.className} · ${student.latest}`, id: student.id }));
    const taskResults = initialTasks
      .filter((task) => `${task.title}${task.kind}${task.link}`.includes(query))
      .map((task) => ({ type: "事项", title: task.title, meta: `${task.due} · ${task.link}`, id: task.id }));
    return [...studentResults, ...taskResults].slice(0, 6);
  }, [globalQuery]);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const shouldUseReadOnlyMode = params.get("mode") === "mobile" || window.matchMedia("(max-width: 680px)").matches;
    if (!shouldUseReadOnlyMode) return;
    const timer = window.setTimeout(() => setReadOnly(true), 0);
    return () => window.clearTimeout(timer);
  }, []);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2600);
    return () => window.clearTimeout(timer);
  }, [toast]);

  function selectSearchResult(result: { type: string; id: string }) {
    if (result.type === "学生") {
      setSelectedStudentId(result.id);
      setActiveView("students");
    } else {
      setActiveView("tasks");
    }
    setSearchOpen(false);
    setGlobalQuery("");
  }

  function toggleTask(id: string) {
    setCompletedTasks((current) =>
      current.includes(id) ? current.filter((taskId) => taskId !== id) : [...current, id],
    );
  }

  function finishQuickAdd(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setQuickAddOpen(false);
    setToast("记录已加入待整理区");
  }

  function completeImport() {
    setImportStep(3);
    setToast("课表草稿已确认写入演示工作台");
  }

  function completePublish() {
    setPublishStep(3);
    setLastPublished("刚刚");
    setToast("手机只读快照已生成");
  }

  return (
    <div className={`workbench-shell ${readOnly ? "is-read-only" : ""}`}>
      <aside className="sidebar" aria-label="主要导航">
        <div className="brand-lockup">
          <span className="brand-mark" aria-hidden="true">禾</span>
          <span>
            <strong>教师个人工作台</strong>
            <small>林澄老师 · 本地演示</small>
          </span>
        </div>

        <div className="demo-chip"><span aria-hidden="true">●</span> 全部为虚构演示数据</div>

        <nav className="main-nav">
          {navItems.map((item) => (
            <button
              key={item.key}
              type="button"
              className={activeView === item.key ? "active" : ""}
              onClick={() => setActiveView(item.key)}
              aria-current={activeView === item.key ? "page" : undefined}
            >
              <span className="nav-icon" aria-hidden="true">{item.icon}</span>
              <span>{item.label}</span>
              {item.key === "tasks" ? <span className="nav-count">5</span> : null}
            </button>
          ))}
        </nav>

        <div className="sidebar-spacer" />

        <div className="local-status-card">
          <div className="status-heading"><span className="status-dot" /> 本机数据正常</div>
          <p>数据仅保存在这台电脑。手机显示的是上次发布的只读快照。</p>
          <button type="button" className="text-button" onClick={() => setPublishOpen(true)}>查看发布状态 <span>→</span></button>
        </div>

        <button type="button" className="profile-row">
          <span className="teacher-avatar">林</span>
          <span><strong>林澄</strong><small>云杉实验中学（虚构）</small></span>
          <span aria-hidden="true">···</span>
        </button>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <button type="button" className="mobile-brand" onClick={() => setActiveView("today")}>
            <span className="brand-mark" aria-hidden="true">禾</span>
            <strong>教师工作台</strong>
          </button>

          <div className="search-wrap">
            <button type="button" className="global-search" onClick={() => setSearchOpen(true)} aria-label="打开全局搜索">
              <span aria-hidden="true">⌕</span>
              <span>搜索学生、课次、任务和资料</span>
              <kbd>⌘ K</kbd>
            </button>
          </div>

          <div className="topbar-actions">
            {readOnly ? (
              <span className="readonly-badge"><span aria-hidden="true">◉</span> 手机只读</span>
            ) : (
              <>
                <button type="button" className="icon-button" aria-label="通知"><span aria-hidden="true">♢</span><i /></button>
                <button type="button" className="button button-ghost" onClick={() => setMobilePreviewOpen(true)}>预览手机</button>
                <button type="button" className="button button-primary" onClick={() => { setPublishStep(1); setPublishOpen(true); }}>
                  <span aria-hidden="true">↑</span> 发布到手机
                </button>
              </>
            )}
          </div>
        </header>

        {readOnly ? (
          <div className="readonly-strip"><strong>只读快照</strong><span>数据更新于 {lastPublished}</span><span>如需修改，请回到电脑端发布新版本。</span></div>
        ) : null}

        <div className="page-content">
          {activeView === "today" ? (
            <TodayView
              completedTasks={completedTasks}
              onToggleTask={toggleTask}
              onOpenLesson={() => setLessonOpen(true)}
              onOpenQuickAdd={() => setQuickAddOpen(true)}
              onOpenAgentDraft={() => setAgentDraftOpen(true)}
              onGoTasks={() => setActiveView("tasks")}
              onGoStudents={() => setActiveView("students")}
              readOnly={readOnly}
            />
          ) : null}
          {activeView === "teaching" ? (
            <TeachingView
              onOpenLesson={() => setLessonOpen(true)}
              onOpenImport={() => { setImportStep(1); setImportOpen(true); }}
              readOnly={readOnly}
            />
          ) : null}
          {activeView === "students" ? (
            <StudentsView
              filteredStudents={filteredStudents}
              selectedStudent={selectedStudent}
              studentQuery={studentQuery}
              studentClass={studentClass}
              onQuery={setStudentQuery}
              onClass={setStudentClass}
              onSelect={setSelectedStudentId}
              onQuickAdd={() => setQuickAddOpen(true)}
              readOnly={readOnly}
            />
          ) : null}
          {activeView === "tasks" ? (
            <TasksView
              tasks={filteredTasks}
              taskFilter={taskFilter}
              completedTasks={completedTasks}
              onFilter={setTaskFilter}
              onToggleTask={toggleTask}
              onQuickAdd={() => setQuickAddOpen(true)}
              readOnly={readOnly}
            />
          ) : null}
          {activeView === "resources" ? (
            <ResourcesView
              onOpenImport={() => { setImportStep(1); setImportOpen(true); }}
              onOpenAgentDraft={() => setAgentDraftOpen(true)}
              readOnly={readOnly}
            />
          ) : null}
        </div>
      </main>

      <nav className="mobile-bottom-nav" aria-label="手机导航">
        {navItems.map((item) => (
          <button key={item.key} type="button" className={activeView === item.key ? "active" : ""} onClick={() => setActiveView(item.key)}>
            <span aria-hidden="true">{item.icon}</span><small>{item.label}</small>
          </button>
        ))}
      </nav>

      {searchOpen ? (
        <div className="modal-backdrop modal-top" role="presentation" onMouseDown={() => setSearchOpen(false)}>
          <section className="search-dialog" role="dialog" aria-modal="true" aria-label="全局搜索" onMouseDown={(event) => event.stopPropagation()}>
            <div className="search-input-row">
              <span aria-hidden="true">⌕</span>
              <input autoFocus value={globalQuery} onChange={(event) => setGlobalQuery(event.target.value)} placeholder="输入姓名、班级、任务或资料名称" aria-label="搜索关键词" />
              <button type="button" onClick={() => setSearchOpen(false)}>ESC</button>
            </div>
            <div className="search-results">
              {!globalQuery ? (
                <div className="search-hint"><strong>可以试试</strong><span>“赵清禾”</span><span>“运动会”</span><span>“论文”</span></div>
              ) : searchResults.length ? searchResults.map((result) => (
                <button key={`${result.type}-${result.id}`} type="button" onClick={() => selectSearchResult(result)}>
                  <Pill tone={result.type === "学生" ? "sage" : "apricot"}>{result.type}</Pill>
                  <span><strong>{result.title}</strong><small>{result.meta}</small></span>
                  <span aria-hidden="true">→</span>
                </button>
              )) : <div className="empty-search">没有找到相关内容</div>}
            </div>
          </section>
        </div>
      ) : null}

      {quickAddOpen ? (
        <Modal title="快速记录" subtitle="先记下来，稍后可以继续补充和关联。" onClose={() => setQuickAddOpen(false)}>
          <form className="quick-form" onSubmit={finishQuickAdd}>
            <div className="segmented-control" aria-label="记录类型">
              <button type="button" className="active">学生观察</button>
              <button type="button">新事项</button>
              <button type="button">随手记</button>
            </div>
            <label>关联对象<select defaultValue="八年级4班 · 李明澈"><option>八年级4班 · 李明澈</option><option>八年级2班 · 陈屿安</option><option>八年级6班 · 郑书言</option></select></label>
            <label>事实记录<textarea required placeholder="只记录今天看见或听见的具体事实……" defaultValue="在课本中补充标出第三处动作描写，并写下对应段落位置。" /></label>
            <label>后续计划<input placeholder="可选：下次需要确认什么？" /></label>
            <p className="form-note"><span aria-hidden="true">i</span> 事实记录与教师判断分开保存，避免形成固定标签。</p>
            <div className="modal-actions"><button type="button" className="button button-ghost" onClick={() => setQuickAddOpen(false)}>取消</button><button type="submit" className="button button-primary">保存记录</button></div>
          </form>
        </Modal>
      ) : null}

      {lessonOpen ? <LessonModal onClose={() => setLessonOpen(false)} onAdd={() => { setLessonOpen(false); setQuickAddOpen(true); }} /> : null}
      {importOpen ? <ImportModal step={importStep} onStep={setImportStep} onClose={() => setImportOpen(false)} onComplete={completeImport} /> : null}
      {publishOpen ? (
        <PublishModal
          step={publishStep}
          lastPublished={lastPublished}
          onStep={setPublishStep}
          onClose={() => setPublishOpen(false)}
          onComplete={completePublish}
          onPreview={() => { setPublishOpen(false); setMobilePreviewOpen(true); }}
        />
      ) : null}
      {agentDraftOpen ? <AgentDraftModal onClose={() => setAgentDraftOpen(false)} onAccept={() => { setAgentDraftOpen(false); setToast("变更已采用，可随时撤销"); }} /> : null}
      {mobilePreviewOpen ? <MobilePreview lastPublished={lastPublished} onClose={() => setMobilePreviewOpen(false)} /> : null}

      {toast ? <div className="toast" role="status"><span aria-hidden="true">✓</span>{toast}</div> : null}
    </div>
  );
}

function TodayView({
  completedTasks,
  onToggleTask,
  onOpenLesson,
  onOpenQuickAdd,
  onOpenAgentDraft,
  onGoTasks,
  onGoStudents,
  readOnly,
}: {
  completedTasks: string[];
  onToggleTask: (id: string) => void;
  onOpenLesson: () => void;
  onOpenQuickAdd: () => void;
  onOpenAgentDraft: () => void;
  onGoTasks: () => void;
  onGoStudents: () => void;
  readOnly: boolean;
}) {
  return (
    <>
      <SectionHeader
        eyebrow="2026年9月15日 · 周二"
        title="下午好，林老师"
        description="今天的课已经结束，还有 3 件需要收口的事。"
        actions={!readOnly ? <button type="button" className="button button-soft" onClick={onOpenQuickAdd}><span aria-hidden="true">＋</span> 快速记录</button> : undefined}
      />

      <div className="today-grid">
        <button type="button" className="next-lesson-card" onClick={onOpenLesson}>
          <div className="next-lesson-top"><Pill tone="dark">下一步</Pill><span>课后收口 · 建议现在完成</span></div>
          <div className="lesson-time-block"><span className="time-large">15:50</span><span className="time-range">— 16:35</span></div>
          <div className="lesson-main-copy">
            <p>八年级4班 · 班会</p>
            <h2>秋季运动会分工与报名确认</h2>
            <span>304教室 · 已完成课堂记录</span>
          </div>
          <div className="lesson-checks">
            <span><i className="check-done">✓</i>点名已完成</span>
            <span><i className="check-done">✓</i>4条事实记录</span>
            <span><i className="check-wait">•</i>1项后续待创建</span>
          </div>
          <span className="card-arrow" aria-hidden="true">↗</span>
        </button>

        <section className="card focus-card">
          <div className="card-heading"><div><p className="eyebrow">今天最值得先做</p><h2>收口清单</h2></div><Pill tone="apricot">约 35 分钟</Pill></div>
          <div className="focus-list">
            {initialTasks.slice(0, 3).map((task, index) => {
              const done = completedTasks.includes(task.id);
              return (
                <div key={task.id} className={`focus-item ${done ? "done" : ""}`}>
                  <button type="button" className="task-check" onClick={() => onToggleTask(task.id)} aria-label={`${done ? "恢复" : "完成"}${task.title}`}>{done ? "✓" : index + 1}</button>
                  <button type="button" className="focus-copy" onClick={onGoTasks}><strong>{task.title}</strong><span>{task.due} · {task.duration}</span></button>
                </div>
              );
            })}
          </div>
          <button type="button" className="text-button wide" onClick={onGoTasks}>查看全部事项 <span>→</span></button>
        </section>

        <section className="card followup-card">
          <div className="card-heading"><div><p className="eyebrow">学生</p><h2>待跟进</h2></div><button type="button" className="count-bubble" onClick={onGoStudents}>4</button></div>
          <div className="student-stack">
            {students.slice(0, 3).map((student) => (
              <button type="button" key={student.id} className="student-mini-row" onClick={onGoStudents}>
                <Avatar student={student} size="small" />
                <span><strong>{student.name}<small>{student.className.replace("年级", "")}</small></strong><em>{student.followUp}</em></span>
                <span aria-hidden="true">›</span>
              </button>
            ))}
          </div>
          <button type="button" className="text-button wide" onClick={onGoStudents}>进入学生看板 <span>→</span></button>
        </section>

        <section className="card agent-card">
          <div className="agent-mark" aria-hidden="true">✦</div>
          <div><p className="eyebrow">Agent 待确认</p><h2>2项变更草稿</h2><p>已从今天的课堂记录中整理出 1 项学生跟进和 1 份课后小结，尚未写入正式数据。</p></div>
          <button type="button" className="button button-dark" onClick={onOpenAgentDraft}>检查后采用</button>
        </section>

        <section className="card week-card">
          <div className="card-heading"><div><p className="eyebrow">本周节奏</p><h2>教学收口率</h2></div><strong className="big-number">78%</strong></div>
          <div className="week-bars" aria-label="本周教学收口率">
            {[92, 78, 64, 42, 18].map((value, index) => <span key={index}><i style={{ height: `${value}%` }} /><small>{["一", "二", "三", "四", "五"][index]}</small></span>)}
          </div>
          <p className="muted-copy">本周 9 个课次已完成 7 个收口，比上周更及时。</p>
        </section>
      </div>
    </>
  );
}

function TeachingView({ onOpenLesson, onOpenImport, readOnly }: { onOpenLesson: () => void; onOpenImport: () => void; readOnly: boolean }) {
  return (
    <>
      <SectionHeader
        eyebrow="2026—2027学年第一学期"
        title="教学安排"
        description="课表是工作台的时间骨架，每一节课都能接续记录、资料与学生跟进。"
        actions={!readOnly ? <><button type="button" className="button button-ghost" onClick={onOpenImport}>导入课表</button><button type="button" className="button button-primary" onClick={onOpenLesson}>＋ 新建课次</button></> : undefined}
      />

      <div className="metric-row">
        <div className="metric-card"><span className="metric-icon sage">课</span><p>本周课次<strong>18</strong><small>已完成 7 节</small></p></div>
        <div className="metric-card"><span className="metric-icon apricot">班</span><p>任教班级<strong>3</strong><small>共 129 名学生</small></p></div>
        <div className="metric-card"><span className="metric-icon blue">收</span><p>待收口课次<strong>2</strong><small>建议今天完成</small></p></div>
        <div className="metric-card"><span className="metric-icon violet">资</span><p>本周复用资料<strong>12</strong><small>节省约 95 分钟</small></p></div>
      </div>

      <section className="card schedule-card">
        <div className="schedule-toolbar">
          <div><button type="button" className="square-button" aria-label="上一周">‹</button><button type="button" className="date-button">9月14日—9月18日</button><button type="button" className="square-button" aria-label="下一周">›</button></div>
          <div className="segmented-control compact"><button type="button">日</button><button type="button" className="active">周</button><button type="button">月</button></div>
        </div>
        <div className="schedule-table" role="table" aria-label="本周课表">
          <div className="schedule-row schedule-head" role="row"><span role="columnheader">时间</span>{["周一 14", "周二 15", "周三 16", "周四 17", "周五 18"].map((day, index) => <span key={day} role="columnheader" className={index === 1 ? "today" : ""}>{day}</span>)}</div>
          {scheduleRows.map((row) => (
            <div className="schedule-row" role="row" key={row.time}>
              <span className="schedule-time" role="cell">{row.time}</span>
              {[row.mon, row.tue, row.wed, row.thu, row.fri].map((lesson, index) => (
                <button type="button" role="cell" key={`${row.time}-${index}`} className={`${index === 1 ? "today" : ""} ${lesson.includes("备课") || lesson.includes("自由") ? "light" : ""}`} onClick={onOpenLesson}>
                  <strong>{lesson.split(" · ")[0]}</strong>{lesson.includes(" · ") ? <small>{lesson.split(" · ")[1]}</small> : null}
                </button>
              ))}
            </div>
          ))}
        </div>
      </section>
    </>
  );
}

function StudentsView({
  filteredStudents,
  selectedStudent,
  studentQuery,
  studentClass,
  onQuery,
  onClass,
  onSelect,
  onQuickAdd,
  readOnly,
}: {
  filteredStudents: Student[];
  selectedStudent: Student;
  studentQuery: string;
  studentClass: string;
  onQuery: (value: string) => void;
  onClass: (value: string) => void;
  onSelect: (id: string) => void;
  onQuickAdd: () => void;
  readOnly: boolean;
}) {
  return (
    <>
      <SectionHeader
        eyebrow="事实记录，不做黑盒标签"
        title="学生档案"
        description="从每一次具体课堂证据出发，看见变化，也保留判断依据。"
        actions={!readOnly ? <><button type="button" className="button button-ghost">导入名单</button><button type="button" className="button button-primary" onClick={onQuickAdd}>＋ 记录观察</button></> : undefined}
      />

      <div className="student-summary-row">
        <button type="button" className="summary-chip active"><span>129</span><small>全部学生</small></button>
        <button type="button" className="summary-chip"><span>4</span><small>待跟进</small></button>
        <button type="button" className="summary-chip"><span>2</span><small>资料待补全</small></button>
        <button type="button" className="summary-chip"><span>1</span><small>请假补学中</small></button>
      </div>

      <div className="students-layout">
        <section className="card student-list-card">
          <div className="list-controls">
            <label className="inline-search"><span aria-hidden="true">⌕</span><input value={studentQuery} onChange={(event) => onQuery(event.target.value)} placeholder="搜索学生或记录" /></label>
            <select value={studentClass} onChange={(event) => onClass(event.target.value)} aria-label="筛选班级"><option>全部班级</option><option>八年级2班</option><option>八年级4班</option><option>八年级6班</option></select>
          </div>
          <div className="student-list">
            {filteredStudents.map((student) => (
              <button type="button" key={student.id} className={selectedStudent.id === student.id ? "active" : ""} onClick={() => onSelect(student.id)}>
                <Avatar student={student} size="small" />
                <span><strong>{student.name}</strong><small>{student.className}</small></span>
                {student.followUp !== "暂无待跟进" ? <i title="有待跟进事项" /> : null}
              </button>
            ))}
            {!filteredStudents.length ? <div className="empty-list">没有符合条件的学生</div> : null}
          </div>
        </section>

        <section className="card student-detail-card">
          <div className="student-profile-head">
            <Avatar student={selectedStudent} size="large" />
            <div><div className="name-line"><h2>{selectedStudent.name}</h2><Pill tone="sage">{selectedStudent.className}</Pill></div><p>档案编号 {selectedStudent.id} · 最近更新于今天</p></div>
            {!readOnly ? <button type="button" className="button button-soft" onClick={onQuickAdd}>记录新情况</button> : null}
          </div>

          <div className="student-facts-grid">
            <div><small>最近学习证据</small><strong>{selectedStudent.latest}</strong></div>
            <div><small>出勤摘要</small><strong>{selectedStudent.attendance}</strong></div>
            <div><small>明确待跟进</small><strong>{selectedStudent.followUp}</strong></div>
          </div>

          <div className="detail-split">
            <div className="timeline-panel">
              <div className="subheading"><h3>事实时间线</h3><button type="button">全部记录⌄</button></div>
              <div className="timeline">
                {selectedStudent.timeline.map((event, index) => (
                  <article key={`${event.date}-${index}`}>
                    <span className="timeline-dot" />
                    <div className="timeline-meta"><time>{event.date}</time><Pill tone={index === 0 ? "sage" : "neutral"}>{event.type}</Pill></div>
                    <p>{event.fact}</p>
                    {event.next ? <div className="next-action"><span aria-hidden="true">→</span><span><small>教师后续计划</small>{event.next}</span></div> : null}
                  </article>
                ))}
              </div>
            </div>
            <aside className="student-side-panel">
              <div className="score-card"><span><small>近期测评</small><strong>{selectedStudent.score}</strong></span><Pill tone="sage">较上次 {selectedStudent.trend}</Pill><div className="sparkline" aria-label="近期成绩呈上升趋势"><i style={{ height: "34%" }} /><i style={{ height: "48%" }} /><i style={{ height: "43%" }} /><i style={{ height: "68%" }} /><i style={{ height: "81%" }} /></div></div>
              <div className="evidence-note"><strong>记录原则</strong><p>工作台只呈现可回到原始记录的事实，不自动生成“问题学生”等固定标签。</p></div>
            </aside>
          </div>
        </section>
      </div>
    </>
  );
}

function TasksView({ tasks, taskFilter, completedTasks, onFilter, onToggleTask, onQuickAdd, readOnly }: { tasks: WorkTask[]; taskFilter: TaskKind; completedTasks: string[]; onFilter: (filter: TaskKind) => void; onToggleTask: (id: string) => void; onQuickAdd: () => void; readOnly: boolean }) {
  const filters: TaskKind[] = ["全部", "教学", "学生", "行政", "论文"];
  return (
    <>
      <SectionHeader
        eyebrow="一个任务引擎，覆盖不同工作域"
        title="事项中心"
        description="行政、学科、学生跟进和论文任务都回到同一条时间线。"
        actions={!readOnly ? <button type="button" className="button button-primary" onClick={onQuickAdd}>＋ 新建事项</button> : undefined}
      />
      <div className="tasks-layout">
        <section className="card tasks-main-card">
          <div className="tasks-toolbar">
            <div className="filter-chips">{filters.map((filter) => <button key={filter} type="button" className={taskFilter === filter ? "active" : ""} onClick={() => onFilter(filter)}>{filter}{filter === "全部" ? <span>5</span> : null}</button>)}</div>
            <button type="button" className="sort-button">按截止时间 ↕</button>
          </div>
          <div className="task-list-full">
            {tasks.map((task) => {
              const done = completedTasks.includes(task.id);
              return (
                <article key={task.id} className={done ? "done" : ""}>
                  {!readOnly ? <button type="button" className="round-check" onClick={() => onToggleTask(task.id)} aria-label={`${done ? "恢复" : "完成"}${task.title}`}>{done ? "✓" : ""}</button> : <span className="round-check readonly" />}
                  <div className="task-body">
                    <div className="task-title-line"><Pill tone={task.kind === "教学" ? "sage" : task.kind === "学生" ? "blue" : task.kind === "行政" ? "apricot" : "violet"}>{task.kind}</Pill>{task.urgent ? <Pill tone="rose">即将到期</Pill> : null}</div>
                    <h3>{task.title}</h3>
                    <p><span>◷ {task.due}</span><span>◌ {task.duration}</span><span>↗ {task.link}</span></p>
                    {task.progress ? <div className="task-progress"><span><i style={{ width: "41%" }} /></span><small>{task.progress}</small></div> : null}
                  </div>
                  <button type="button" className="more-button" aria-label={`打开${task.title}`}>···</button>
                </article>
              );
            })}
          </div>
        </section>
        <aside className="tasks-aside">
          <section className="card workload-card"><p className="eyebrow">本周负荷</p><h2>还有 3小时20分</h2><p>已安排事项约 5小时10分，周四下午有一段完整空档。</p><div className="load-bar"><i /></div><div className="load-legend"><span><i className="filled" />已安排 61%</span><span><i />可用 39%</span></div></section>
          <section className="card project-card"><div className="card-heading"><div><p className="eyebrow">论文项目</p><h2>课堂提问研究</h2></div><span className="project-progress">3 / 8</span></div><div className="project-steps"><span className="done">选题</span><span className="done">资料搜集</span><span className="active">文献阅读</span><span>研究设计</span><span>初稿</span></div></section>
        </aside>
      </div>
    </>
  );
}

function ResourcesView({ onOpenImport, onOpenAgentDraft, readOnly }: { onOpenImport: () => void; onOpenAgentDraft: () => void; readOnly: boolean }) {
  return (
    <>
      <SectionHeader
        eyebrow="一次整理，持续复用"
        title="资料与导入"
        description="教案、课件、表格和历史产物都可以关联到课次、学生或任务。"
        actions={!readOnly ? <><button type="button" className="button button-ghost" onClick={onOpenImport}>导入资料</button><button type="button" className="button button-primary">＋ 新建文档</button></> : undefined}
      />
      <div className="resource-toolbar card"><label className="inline-search"><span aria-hidden="true">⌕</span><input placeholder="搜索资料名称、标签或关联课次" /></label><div className="filter-chips"><button type="button" className="active">全部</button><button type="button">教案</button><button type="button">课件</button><button type="button">表格</button><button type="button">论文</button></div></div>
      <div className="resource-grid">
        {resources.map((resource) => <button type="button" className="resource-card card" key={resource.name}><span className={`file-mark ${resource.tone}`}>{resource.type.slice(0, 1)}</span><span><Pill tone={resource.tone}>{resource.type}</Pill><strong>{resource.name}</strong><small>{resource.meta}</small></span><i aria-hidden="true">···</i></button>)}
        {!readOnly ? <button type="button" className="resource-card card import-card" onClick={onOpenImport}><span className="import-plus">＋</span><span><strong>从截图、表格或文件导入</strong><small>Agent 先生成待确认草稿，不直接改正式数据</small></span></button> : null}
      </div>
      {!readOnly ? <section className="agent-review-banner"><span className="agent-mark" aria-hidden="true">✦</span><div><Pill tone="dark">Agent 变更单</Pill><h2>今天有 2 项内容等待你的确认</h2><p>根据课堂记录生成，不会在你确认前写入学生档案。</p></div><button type="button" className="button button-dark" onClick={onOpenAgentDraft}>现在检查</button></section> : null}
    </>
  );
}

function Modal({ title, subtitle, onClose, children, wide = false }: { title: string; subtitle?: string; onClose: () => void; children: React.ReactNode; wide?: boolean }) {
  return (
    <div className="modal-backdrop" role="presentation" onMouseDown={onClose}>
      <section className={`modal-card ${wide ? "modal-wide" : ""}`} role="dialog" aria-modal="true" aria-label={title} onMouseDown={(event) => event.stopPropagation()}>
        <header><div><h2>{title}</h2>{subtitle ? <p>{subtitle}</p> : null}</div><button type="button" className="modal-close" onClick={onClose} aria-label="关闭">×</button></header>
        {children}
      </section>
    </div>
  );
}

function LessonModal({ onClose, onAdd }: { onClose: () => void; onAdd: () => void }) {
  return (
    <Modal title="八年级4班 · 班会" subtitle="9月15日 15:50—16:35 · 304教室" onClose={onClose} wide>
      <div className="lesson-modal-grid">
        <div>
          <div className="lesson-status-line"><Pill tone="sage">已完成</Pill><span>课次记录已保存</span></div>
          <section className="modal-section"><p className="eyebrow">本次目标</p><h3>秋季运动会分工与报名确认</h3><ul className="check-list"><li className="done">确认个人项目报名</li><li className="done">梳理志愿岗位与人数</li><li>将结果汇总为行政任务</li></ul></section>
          <section className="modal-section"><div className="subheading"><h3>课堂事实记录</h3><button type="button" onClick={onAdd}>＋ 添加</button></div><div className="fact-record"><time>15:58</time><p><strong>赵清禾</strong>将小组提出的 5 项建议按“报名、物资、秩序”分为三类；汇报前询问每组发言时长。</p></div><div className="fact-record"><time>16:19</time><p><strong>全班</strong>完成个人项目意向确认，仍有 3 个志愿岗位人数不足。</p></div></section>
        </div>
        <aside className="lesson-side"><section><p className="eyebrow">课后收口</p><h3>还差最后一步</h3><p>把 3 个缺口岗位加入运动会报名汇总任务。</p><button type="button" className="button button-primary wide-button">生成后续事项</button></section><section><p className="eyebrow">关联资料</p><button type="button" className="linked-file"><span>表</span><strong>运动会报名模板.xlsx</strong></button><button type="button" className="linked-file"><span>记</span><strong>班会分组记录.md</strong></button></section></aside>
      </div>
      <div className="modal-actions"><button type="button" className="button button-ghost" onClick={onClose}>关闭</button><button type="button" className="button button-primary" onClick={onAdd}>记录课堂情况</button></div>
    </Modal>
  );
}

function ImportModal({ step, onStep, onClose, onComplete }: { step: number; onStep: (step: number) => void; onClose: () => void; onComplete: () => void }) {
  return (
    <Modal title="导入课表" subtitle="图片、PDF、Excel 或复制表格都可以先交给 Agent 解析。" onClose={onClose} wide>
      <div className="stepper"><span className={step >= 1 ? "active" : ""}><i>1</i>选择文件</span><b /><span className={step >= 2 ? "active" : ""}><i>2</i>核对识别</span><b /><span className={step >= 3 ? "active" : ""}><i>3</i>确认写入</span></div>
      {step === 1 ? <div className="upload-zone"><span className="upload-mark" aria-hidden="true">↑</span><h3>拖入课表截图或 Excel</h3><p>也可以直接粘贴截图。支持 PNG、JPG、PDF、XLSX、CSV。</p><button type="button" className="button button-soft" onClick={() => onStep(2)}>使用演示课表</button><small>原文件只在本机解析；正式写入前必须由老师确认。</small></div> : null}
      {step === 2 ? <div className="import-review"><div className="review-banner"><span aria-hidden="true">✓</span><p><strong>识别完成：25 个课表格</strong><small>23 项置信度高，2 项需要你确认。</small></p></div><div className="mapping-table"><div><strong>星期</strong><strong>时间</strong><strong>识别内容</strong><strong>状态</strong></div><div><span>周二</span><span>08:10—08:55</span><span>八年级4班 · 语文 · 304</span><Pill tone="sage">已确认</Pill></div><div><span>周二</span><span>09:05—09:50</span><span>八年级2班 · 语文 · 302</span><Pill tone="sage">已确认</Pill></div><div className="needs-review"><span>周四</span><span>10:10—10:55</span><label><input defaultValue="八年级组教研活动" aria-label="修正识别内容" /></label><Pill tone="apricot">请核对</Pill></div></div><div className="modal-actions"><button type="button" className="button button-ghost" onClick={() => onStep(1)}>上一步</button><button type="button" className="button button-primary" onClick={onComplete}>确认并写入</button></div></div> : null}
      {step === 3 ? <div className="success-state"><span className="success-mark">✓</span><h3>课表已经写入工作台</h3><p>已建立 3 个班级、25 个循环课表项，并生成课前与课后提醒草稿。</p><div className="success-stats"><span><strong>25</strong>课表项</span><span><strong>3</strong>班级</span><span><strong>2</strong>待确认提醒</span></div><button type="button" className="button button-primary" onClick={onClose}>完成</button></div> : null}
    </Modal>
  );
}

function PublishModal({ step, lastPublished, onStep, onClose, onComplete, onPreview }: { step: number; lastPublished: string; onStep: (step: number) => void; onClose: () => void; onComplete: () => void; onPreview: () => void }) {
  return (
    <Modal title="发布到手机" subtitle={`手机当前显示 ${lastPublished} 的只读快照。`} onClose={onClose} wide>
      <div className="stepper publish-stepper"><span className={step >= 1 ? "active" : ""}><i>1</i>选择内容</span><b /><span className={step >= 2 ? "active" : ""}><i>2</i>预览快照</span><b /><span className={step >= 3 ? "active" : ""}><i>3</i>完成发布</span></div>
      {step === 1 ? <div className="publish-select"><div className="snapshot-option"><span className="option-mark sage">学</span><span><strong>学生概况与待跟进</strong><small>姓名、班级、近期事实记录和明确后续事项</small></span><input type="checkbox" defaultChecked aria-label="发布学生概况" /></div><div className="snapshot-option"><span className="option-mark blue">课</span><span><strong>课表与课次摘要</strong><small>本周课表、教室、课程目标和课后收口状态</small></span><input type="checkbox" defaultChecked aria-label="发布课表" /></div><div className="snapshot-option"><span className="option-mark apricot">事</span><span><strong>任务与提醒</strong><small>截止时间、进度与关联对象，不含本地附件</small></span><input type="checkbox" defaultChecked aria-label="发布任务" /></div><div className="snapshot-option disabled"><span className="option-mark rose">隐</span><span><strong>私人备注与原始附件</strong><small>默认不发布到手机</small></span><input type="checkbox" disabled aria-label="私人备注不发布" /></div><div className="encryption-note"><span aria-hidden="true">◇</span><p><strong>发布前在本机加密</strong><small>手机只获得读取能力，不保存仓库写权限。</small></p></div><div className="modal-actions"><button type="button" className="button button-ghost" onClick={onClose}>取消</button><button type="button" className="button button-primary" onClick={() => onStep(2)}>生成预览</button></div></div> : null}
      {step === 2 ? <div className="publish-preview"><div className="snapshot-summary"><div><p className="eyebrow">即将发布</p><h3>9月15日手机只读快照</h3><span>128 KB · 加密数据包</span></div><Pill tone="sage">检查通过</Pill></div><div className="preview-columns"><div><small>包含内容</small><strong>3 个班级</strong><strong>8 名演示学生摘要</strong><strong>本周 25 个课表项</strong><strong>5 个未完成事项</strong></div><div><small>不会包含</small><strong>本地附件原文件</strong><strong>AI 密钥或仓库令牌</strong><strong>已关闭的私人备注</strong><strong>任何编辑入口</strong></div></div><div className="modal-actions"><button type="button" className="button button-ghost" onClick={() => onStep(1)}>返回修改</button><button type="button" className="button button-primary" onClick={onComplete}>确认发布</button></div></div> : null}
      {step === 3 ? <div className="success-state publish-success"><span className="success-mark">↑</span><h3>手机看板已更新</h3><p>新快照已经生成。手机刷新后即可看到，仍然无法新增、编辑或删除。</p><div className="pairing-code"><span className="pairing-visual">禾</span><span><small>首次配对演示码</small><strong>松河 · 27 · 桥</strong><em>正式版由电脑生成一次性二维码</em></span></div><div className="success-buttons"><button type="button" className="button button-ghost" onClick={onClose}>完成</button><button type="button" className="button button-primary" onClick={onPreview}>打开手机预览</button></div></div> : null}
    </Modal>
  );
}

function AgentDraftModal({ onClose, onAccept }: { onClose: () => void; onAccept: () => void }) {
  return (
    <Modal title="Agent 变更草稿" subtitle="Agent 只能生成草稿；采用前你可以检查每一条依据。" onClose={onClose} wide>
      <div className="agent-draft-layout"><aside><p className="eyebrow">依据来源</p><button type="button" className="source-item active"><span>课</span><strong>八6写作课记录<small>今天 10:10—10:55</small></strong></button><button type="button" className="source-item"><span>记</span><strong>郑书言课堂观察<small>今天 10:36</small></strong></button><button type="button" className="source-item"><span>表</span><strong>写作提纲检查表<small>今天更新</small></strong></button></aside><div className="draft-content"><div className="draft-label-line"><Pill tone="violet">建议新增事项</Pill><span>尚未写入正式数据</span></div><label>事项标题<input defaultValue="查看郑书言替换后的论据是否支持观点" /></label><div className="draft-two-cols"><label>截止时间<input defaultValue="2026-09-16 18:00" /></label><label>关联对象<input defaultValue="郑书言 · 八年级6班" /></label></div><label>依据摘要<textarea defaultValue="今天写作课上，郑书言核对提纲时主动标出一个与观点关系不直接的事例，并注明“待更换”。后续只检查新论据与观点的对应关系。" /></label><div className="draft-safety"><span aria-hidden="true">i</span><p><strong>为什么建议这项变更？</strong>原始记录中同时出现了明确的待更换动作和教师后续检查计划，没有推断学生的稳定能力或态度。</p></div></div></div>
      <div className="modal-actions"><button type="button" className="button button-ghost" onClick={onClose}>放弃</button><button type="button" className="button button-soft">继续修改</button><button type="button" className="button button-primary" onClick={onAccept}>采用这项变更</button></div>
    </Modal>
  );
}

function MobilePreview({ lastPublished, onClose }: { lastPublished: string; onClose: () => void }) {
  return (
    <div className="mobile-preview-backdrop" role="presentation" onMouseDown={onClose}>
      <div className="phone-demo-wrap" role="dialog" aria-modal="true" aria-label="手机只读预览" onMouseDown={(event) => event.stopPropagation()}>
        <button type="button" className="phone-close" onClick={onClose}>关闭预览 ×</button>
        <div className="phone-frame">
          <div className="phone-status"><span>16:48</span><span>◒ 5G ▰</span></div>
          <header><span className="brand-mark">禾</span><span><strong>林老师的工作台</strong><small>只读快照 · 更新于 {lastPublished}</small></span></header>
          <main>
            <section className="phone-hero"><Pill tone="dark">今天已结束</Pill><h2>还有 3 件事<br />需要收口</h2><p>手机端仅用于查看，修改请回到电脑。</p></section>
            <section><div className="phone-section-head"><h3>最近事项</h3><span>查看全部</span></div>{initialTasks.slice(0, 3).map((task) => <div className="phone-task" key={task.id}><span className={`phone-task-dot ${task.kind}`} /><span><strong>{task.title}</strong><small>{task.due} · {task.link}</small></span></div>)}</section>
            <section><div className="phone-section-head"><h3>学生待跟进</h3><span>4 人</span></div><div className="phone-students">{students.slice(0, 4).map((student) => <span key={student.id}><Avatar student={student} size="small" /><small>{student.name}</small></span>)}</div></section>
          </main>
          <nav><button type="button" className="active"><span>⌂</span><small>今日</small></button><button type="button"><span>◎</span><small>学生</small></button><button type="button"><span>▦</span><small>课表</small></button><button type="button"><span>✓</span><small>事项</small></button></nav>
        </div>
        <div className="phone-preview-note"><strong>这里没有编辑入口</strong><p>手机只下载加密快照并在本机查看，不保存 Git 写权限。</p></div>
      </div>
    </div>
  );
}
